import './style.css';

export default function About() {
  return (
    <div className="about-container">
      {/* Video Background */}
      <video className="background-video" autoPlay loop muted>
        <source src="/src/assets/HeroSec.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Content Overlay */}
      <div className="content-overlay">
        {/* About Us Section */}
        <div className="about-box">
          <header className="about-header">
            <h1>About Us</h1>
            <p>
              Welcome to Eventora! We are dedicated to making your events
              memorable and seamless. Whether you're an admin, event manager, or
              customer, our platform is designed to cater to your needs.
            </p>
          </header>
        </div>

        {/* Event Types Section */}
        <div className="event-types">
          <div className="event-card">
            <img
              src="/src/assets/marriage.jpg"
              alt="Marriage Events"
              className="event-image"
            />
            <h3>Marriage Events</h3>
            <p>Celebrate your special day with elegance and style.</p>
          </div>
          <div className="event-card">
            <img
              src="/src/assets/birthday.jpg"
              alt="Birthday Parties"
              className="event-image"
            />
            <h3>Birthday Parties</h3>
            <p>Make birthdays unforgettable with our unique setups.</p>
          </div>
          <div className="event-card">
            <img
              src="/src/assets/corporate.jpeg"
              alt="Corporate Events"
              className="event-image"
            />
            <h3>Corporate Events</h3>
            <p>Host professional events with seamless execution.</p>
          </div>
        </div>

        {/* Map Section */}
        <div className="map-container">
          <h2>Our Locations</h2>
          <iframe
            title="Eventora Locations"
            src="https://www.openstreetmap.org/export/embed.html?bbox=77.0,12.0,85.0,18.0&layer=mapnik&marker=16.5062,80.6480"
            className="map"
            allowFullScreen
          ></iframe>
        </div>

        {/* Footer Section */}
        <footer className="footer">
          <p>Best wishes from the Eventora team! 🎉</p>
        </footer>
      </div>
    </div>
  );
}