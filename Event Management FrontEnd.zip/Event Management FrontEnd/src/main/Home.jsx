import './style.css'; 

export default function Home() {
  return (
    <div className="home-container">
      {/* Video Background */}
      <video className="background-video" autoPlay loop muted>
        <source src="/src/assets/HeroSec.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Content Overlay */}
      <div className="content-overlay">
        {/* Logo Section */}
        <div className="logo-container">
          <img
            src="/src/assets/logoev.jpg" // Replace with the actual path to your logo
            alt="Logo"
            className="big-logo"
          />
        </div>

        {/* Header Section */}
        <header className="home-header">
          <h1>Every day is memorable with us..!</h1>
          <p>Manage events seamlessly for Admins, Managers, and Customers</p>
        </header>

        {/* Sections */}
        <div className="sections-container">
          <div className="section-card admin-section">
            <h3>Admin</h3>
            <ul>
              <li>Admin Login</li>
              <li>Add Event Manager</li>
              <li>View/Delete Event Managers</li>
              <li>View Customers</li>
              <li>Delete/Block Customer</li>
              <li>View All Events</li>
            </ul>
          </div>
          <div className="section-card manager-section">
            <h3>Event Manager</h3>
            <ul>
              <li>Event Manager Login</li>
              <li>View/Update Profile</li>
              <li>Add New Event</li>
              <li>View Events</li>
              <li>View Bookings</li>
            </ul>
          </div>
          <div className="section-card customer-section">
            <h3>Customer</h3>
            <ul>
              <li>Registration</li>
              <li>Customer Login</li>
              <li>View/Update Profile</li>
              <li>Book an Event</li>
              <li>View Booked Events</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}