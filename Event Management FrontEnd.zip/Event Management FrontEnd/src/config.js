const config = 
{
    "url":"http://localhost:2017"
}

export default config