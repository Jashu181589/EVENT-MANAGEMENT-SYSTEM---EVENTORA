import React, { useEffect, useState } from 'react';
import axios from 'axios';
import config from '../config';
import './admin.css'; // Import the updated CSS file

export default function AdminHome() {
  const [customerCount, setCustomerCount] = useState(0);
  const [managerCount, setManagerCount] = useState(0);
  const [eventCount, setEventCount] = useState(0);

  useEffect(() => {
    const fetchCounts = async () => {
      try {
        const customerRes = await axios.get(`${config.url}/admin/customercount`);
        const managerRes = await axios.get(`${config.url}/admin/managercount`);
        const eventRes = await axios.get(`${config.url}/admin/eventcount`);

        setCustomerCount(customerRes.data);
        setManagerCount(managerRes.data);
        setEventCount(eventRes.data);
      } catch (error) {
        console.error("Error fetching counts:", error);
      }
    };

    fetchCounts();
  }, []);

  return (
    <div className="admin-home-container">
      {/* Video Background */}
      <video className="background-video" autoPlay loop muted>
        <source src="/src/assets/bg6.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Content Overlay */}
      <div className="content-overlay">
        <h2 className="admin-home-title">HELLOO!! Admin</h2>
        <div className="admin-home-stats">
          <div className="stat-card">
            <h3>Customers</h3>
            <p>{customerCount}</p>
          </div>
          <div className="stat-card">
            <h3>Managers</h3>
            <p>{managerCount}</p>
          </div>
          <div className="stat-card">
            <h3>Events</h3>
            <p>{eventCount}</p>
          </div>
        </div>
      </div>
    </div>
  );
}