import React, { useState } from 'react';
import axios from 'axios';
import config from '../config';
import './admin.css'; // Import the updated CSS file

const AddProduct = () => {
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    description: '',
    cost: '',
    url: '',
    image: null,
  });

  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, image: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formDataToSend = new FormData();
    Object.keys(formData).forEach((key) => {
      formDataToSend.append(key, formData[key]);
    });

    try {
      const response = await axios.post(`${config.url}/product/addproduct`, formDataToSend, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setMessage(response.data);
      setError('');
      setFormData({
        name: '',
        category: '',
        description: '',
        cost: '',
        url: '',
        image: null,
      });
    } catch (err) {
      setError('Failed to add product: ' + err.message);
      setMessage('');
    }
  };

  return (
    <div className="add-product-container">
      {/* Video Background */}
      <video className="background-video" autoPlay loop muted>
        <source src="/src/assets/bg6.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Content Overlay */}
      <div className="content-overlay">
        <h3 className="add-product-title">Add New Product</h3>

        {message && <p className="success-message">{message}</p>}
        {error && <p className="error-message">{error}</p>}

        <form onSubmit={handleSubmit} className="add-product-form">
          <div className="form-group">
            <label>Product Name</label>
            <input
              type="text"
              id="name"
              value={formData.name}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>
          <div className="form-group">
            <label>Category</label>
            <input
              type="text"
              id="category"
              value={formData.category}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>
          <div className="form-group">
            <label>Description</label>
            <textarea
              id="description"
              value={formData.description}
              onChange={handleChange}
              className="form-control"
              rows="4"
              required
            ></textarea>
          </div>
          <div className="form-group">
            <label>Cost</label>
            <input
              type="number"
              id="cost"
              value={formData.cost}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>
          <div className="form-group">
            <label>Product URL</label>
            <input
              type="url"
              id="url"
              value={formData.url}
              onChange={handleChange}
              className="form-control"
              required
            />
          </div>
          <div className="form-group">
            <label>Product Image</label>
            <input
              type="file"
              id="image"
              onChange={handleFileChange}
              className="form-control"
              required
            />
          </div>
          <button type="submit" className="btn-submit">
            Add Product
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddProduct;