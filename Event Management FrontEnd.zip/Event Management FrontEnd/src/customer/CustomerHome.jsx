import { useState, useEffect } from 'react';
import './customer.css';

export default function CustomerHome() {
  const [customer, setCustomer] = useState("");

  useEffect(() => {
    const storedCustomer = sessionStorage.getItem('customer');
    if (storedCustomer) {
      setCustomer(JSON.parse(storedCustomer));
    }
  }, []);

  return (
    <div className="customer-home-container">
      {/* Video Background */}
      <video className="background-video" autoPlay loop muted>
        <source src="/src/assets/bg9.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Content Overlay */}
      <div className="content-overlay">
        <h1 className="customer-home-title">Welcome {customer.name}</h1>
        <p className="customer-home-subtitle">Explore and manage your events seamlessly!</p>
      </div>
    </div>
  );
}