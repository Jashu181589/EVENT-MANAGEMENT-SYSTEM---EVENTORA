import { useState, useEffect } from 'react';
import axios from 'axios';
import config from '../config';
import './customer.css'; // Import the CSS file for styling

export default function BookedEvents() {
  const [bookedEvents, setBookedEvents] = useState([]);
  const [customer, setCustomer] = useState(null);

  useEffect(() => {
    const fetchBookedEvents = async () => {
      const storedCustomer = sessionStorage.getItem('customer');
      if (storedCustomer) {
        const customerData = JSON.parse(storedCustomer);
        setCustomer(customerData);
        try {
          const response = await axios.get(`${config.url}/customer/bookedevents/${customerData.id}`);
          setBookedEvents(response.data);
        } catch (error) {
          console.error('Error fetching booked events:', error);
        }
      } else {
        alert('Please log in to view your booked events.');
      }
    };

    fetchBookedEvents();
  }, []);

  return (
    <div className="booked-events-container">
      {/* Video Background */}
      <video className="background-video" autoPlay loop muted>
        <source src="/src/assets/bg9.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Content Overlay */}
      <div className="content-overlay">
        <h3 className="booked-events-title">Your Booked Events</h3>
        {customer ? (
          <div className="booked-events-table-container">
            <table className="booked-events-table">
              <thead>
                <tr>
                  <th>Booking ID</th>
                  <th>Event Category</th>
                  <th>Event Title</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Booked Capacity</th>
                  <th>Status</th>
                  <th>Booking Time</th>
                </tr>
              </thead>
              <tbody>
                {bookedEvents.length > 0 ? (
                  bookedEvents.map((event, index) => (
                    <tr key={index}>
                      <td>{event.id}</td>
                      <td>{event.event.category}</td>
                      <td>{event.event.title}</td>
                      <td>{event.startdate}</td>
                      <td>{event.enddate}</td>
                      <td>{event.bookedcapacity}</td>
                      <td>{event.status}</td>
                      <td>{new Date(event.bookingtime).toLocaleString()}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="8">No booked events found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        ) : (
          <p>Loading your customer details...</p>
        )}
      </div>
    </div>
  );
}