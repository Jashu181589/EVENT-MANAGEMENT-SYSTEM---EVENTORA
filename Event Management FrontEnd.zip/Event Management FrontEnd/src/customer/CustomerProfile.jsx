import { useState, useEffect } from 'react';
import './customer.css'; // Import the CSS file for styling

export default function CustomerProfile() {
  const [customer, setCustomer] = useState("");

  useEffect(() => {
    const storedCustomer = sessionStorage.getItem('customer');
    if (storedCustomer) {
      setCustomer(JSON.parse(storedCustomer));
    }
  }, []);

  if (!customer) {
    return (
      <div style={{ textAlign: 'center', marginTop: '50px' }}>
        Loading profile...
      </div>
    );
  }

  return (
    <div className="customer-profile-container">
      {/* Video Background */}
      <video className="background-video" autoPlay loop muted>
        <source src="/src/assets/bg9.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Content Overlay */}
      <div className="content-overlay">
        <h2 className="customer-profile-title">Customer Profile</h2>
        <div className="customer-profile-card">
          <p><strong>Name:</strong> {customer.name}</p>
          <p><strong>Gender:</strong> {customer.gender}</p>
          <p><strong>Date of Birth:</strong> {customer.dob}</p>
          <p><strong>Email:</strong> {customer.email}</p>
          <p><strong>Username:</strong> {customer.username}</p>
          <p><strong>Mobile No:</strong> {customer.mobileno}</p>
          <p><strong>Company:</strong> {customer.location}</p>
        </div>
      </div>
    </div>
  );
}