import { useState, useEffect } from 'react';
import './manager.css';

export default function ManagerHome() {
  const [manager, setManager] = useState("");

  useEffect(() => {
    const storedManager = sessionStorage.getItem('manager');
    if (storedManager) {
      setManager(JSON.parse(storedManager));
    }
  }, []);

  return (
    <div className="manager-home-container">
      {/* Video Background */}
      <video className="background-video" autoPlay loop muted>
        <source src="/src/assets/bg8.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Content Overlay */}
      <div className="content-overlay">
        <h1 className="manager-home-title">Welcome Manager</h1>
        <p className="manager-home-subtitle">Hello, {manager.name}! Manage your events efficiently.</p>

        {/* Cards Section */}
        <div className="manager-cards-container">
          <div className="manager-card">
            <img src="/src/assets/checklist.jpg" alt="Checklists" className="manager-card-image" />
            <h3>Checklists</h3>
            <p>Manage and review event checklists.</p>
            <button className="manager-card-button">View Checklists</button>
          </div>
          <div className="manager-card">
            <img src="/src/assets/upcoming.jpg" alt="Upcoming Events" className="manager-card-image" />
            <h3>Upcoming Events</h3>
            <p>View and manage upcoming events.</p>
            <button className="manager-card-button">View Events</button>
          </div>
          <div className="manager-card">
            <img src="/src/assets/completed.jpg" alt="Completed Events" className="manager-card-image" />
            <h3>Completed Events</h3>
            <p>Review completed events and feedback.</p>
            <button className="manager-card-button">View Completed</button>
          </div>
        </div>
      </div>
    </div>
  );
}