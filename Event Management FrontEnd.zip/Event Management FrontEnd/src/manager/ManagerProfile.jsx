import { useState, useEffect } from 'react';
import './manager.css';

export default function ManagerProfile() {
  const [manager, setManager] = useState(null);

  useEffect(() => {
    const storedManager = sessionStorage.getItem('manager');
    if (storedManager) {
      setManager(JSON.parse(storedManager));
    }
  }, []);

  if (!manager) {
    return (
      <div style={{ textAlign: 'center', marginTop: '50px' }}>
        Loading profile...
      </div>
    );
  }

  return (
    <div className="manager-profile-container">
      {/* Video Background */}
      <video className="background-video" autoPlay loop muted>
        <source src="/src/assets/bg8.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Content Overlay */}
      <div className="content-overlay">
        <h2 className="manager-profile-title">Manager Profile</h2>
        <div className="manager-profile-card">
          <p><strong>Name:</strong> {manager.name}</p>
          <p><strong>Gender:</strong> {manager.gender}</p>
          <p><strong>Date of Birth:</strong> {manager.dob}</p>
          <p><strong>Email:</strong> {manager.email}</p>
          <p><strong>Username:</strong> {manager.username}</p>
          <p><strong>Mobile No:</strong> {manager.mobileno}</p>
          <p><strong>Company Name:</strong> {manager.company_name}</p>
          <p><strong>Company Location:</strong> {manager.company_location}</p>
        </div>
      </div>
    </div>
  );
}